Exceptions and Warnings
=======================

.. automodule:: urllib3.exceptions
    :members:
    :undoc-members:
    :show-inheritance:

.. autofunction:: urllib3.disable_warnings
