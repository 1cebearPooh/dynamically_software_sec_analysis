# entry_test.py
import urllib3

def test_connection():
    http = urllib3.PoolManager()
    try:
        # Replace with a test or local URL to avoid external dependencies
        response = http.request('GET', 'https://example.com')
        print(f"Status: {response.status}")
        print(f"Data: {response.data[:100]}")  # Print first 100 characters of the response
    except urllib3.exceptions.HTTPError as e:
        print(f"HTTP Error: {e}")
    except Exception as e:
        print(f"General Error: {e}")

if __name__ == "__main__":
    test_connection()
