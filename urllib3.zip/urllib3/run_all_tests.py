import pytest

# Run all tests in the 'tests' directory
pytest.main(['-n', '8', '--import-mode=importlib', './tests'])
